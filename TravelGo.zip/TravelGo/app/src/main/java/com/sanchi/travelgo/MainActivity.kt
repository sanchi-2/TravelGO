package com.sanchi.travelgo

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.widget.Button
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val btnPlanTrip = findViewById<Button>(R.id.btnPlanTrip)
        val btnBookHotel = findViewById<Button>(R.id.btnBookHotel)
        val btnTrackExpenses = findViewById<Button>(R.id.btnTrackExpenses)

        btnPlanTrip.setOnClickListener {
            startActivity(Intent(this, PlanTripActivity::class.java))
            startActivity(intent)
        }


        btnBookHotel.setOnClickListener {
            Toast.makeText(this, "Book Hotel Clicked", Toast.LENGTH_SHORT).show()
            // startActivity(Intent(this, BookHotelActivity::class.java))
        }

        btnTrackExpenses.setOnClickListener {
            Toast.makeText(this, "Track Expenses Clicked", Toast.LENGTH_SHORT).show()
            // startActivity(Intent(this, TrackExpensesActivity::class.java))
        }

        // Your main screen logic goes here
        // For example, navigate to a new activity on button click:
//        val btnSearch = findViewById<Button>(R.id.btnSearch)
//        btnSearch?.setOnClickListener {
//            val intent = Intent(this, SearchResultsActivity::class.java)
//            startActivity(intent)
        }
    }

