package com.sanchi.travelgo

data class User(
    val email: String = "",
    val password: String = ""
)

