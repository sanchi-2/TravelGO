package com.sanchi.travelgo

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.database.*

class ExpenseTrackerActivity : AppCompatActivity() {

    private lateinit var expenseInput: EditText
    private lateinit var btnAddExpense: Button
    private lateinit var totalExpenseText: TextView

    private lateinit var database: DatabaseReference
    private var totalExpense = 0.0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_expense_tracker)

        expenseInput = findViewById(R.id.expenseInput)
        btnAddExpense = findViewById(R.id.btnAddExpense)
        totalExpenseText = findViewById(R.id.totalExpenseText)

        database = FirebaseDatabase.getInstance().reference.child("expenses")

        // Read total expense from Firebase when activity starts
        database.child("total").addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val value = snapshot.getValue(Double::class.java)
                totalExpense = value ?: 0.0
                totalExpenseText.text = "Total Expense: $%.2f".format(totalExpense)
            }

            override fun onCancelled(error: DatabaseError) {
                Toast.makeText(this@ExpenseTrackerActivity, "Failed to load total expense", Toast.LENGTH_SHORT).show()
            }
        })

        btnAddExpense.setOnClickListener {
            val expense = expenseInput.text.toString().toDoubleOrNull()
            if (expense != null) {
                totalExpense += expense
                // Save updated total to Firebase
                database.child("total").setValue(totalExpense)
                // Optionally store each individual expense entry
                val expenseId = database.child("entries").push().key
                if (expenseId != null) {
                    database.child("entries").child(expenseId).setValue(expense)
                }
                expenseInput.text.clear()
            } else {
                Toast.makeText(this, "Please enter a valid number", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
