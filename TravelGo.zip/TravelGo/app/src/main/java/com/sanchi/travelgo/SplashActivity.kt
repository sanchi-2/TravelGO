package com.sanchi.travelgo

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.firestore.FirebaseFirestore

@SuppressLint("CustomSplashScreen")
class SplashActivity : AppCompatActivity() {

    // Initialize Firestore instance
    private lateinit var firestore: FirebaseFirestore

    @SuppressLint("MissingInflatedId", "WrongViewCast")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)

        // Initialize Firestore
        firestore = FirebaseFirestore.getInstance()

        // Handle splash delay to LoginActivity
        Handler(Looper.getMainLooper()).postDelayed({
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
        }, 3000) // Reduced delay for better UX

        // Add Flight button click
        val btnAddFlight = findViewById<Button>(R.id.tvAddFlight)
        btnAddFlight.setOnClickListener {
            // Prepare sample flight data
            val flight = Flight(
                departureCity = "New York",
                destinationCity = "Los Angeles",
                departureDate = "2025-04-16",
                returnDate = "2025-04-23",
                price = 350.0
            )

            // Save flight data to Firestore
            val flightCollection = firestore.collection("flights")
            flightCollection.add(flight)
                .addOnSuccessListener { documentReference ->
                    Toast.makeText(this, "Flight added successfully", Toast.LENGTH_SHORT).show()
                }
                .addOnFailureListener { e ->
                    Toast.makeText(this, "Failed to add flight: ${e.message}", Toast.LENGTH_SHORT).show()
                }

            // Proceed to the AddFlightActivity
            startActivity(Intent(this, AddFlightActivity::class.java))
        }
    }
}

// Data class for Flight
data class Flight(
    val departureCity: String,
    val destinationCity: String,
    val departureDate: String,
    val returnDate: String,
    val price: Double
)
