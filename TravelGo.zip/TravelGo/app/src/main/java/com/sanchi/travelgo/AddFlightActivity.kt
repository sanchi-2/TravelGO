package com.sanchi.travelgo

import android.annotation.SuppressLint
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase

class AddFlightActivity : AppCompatActivity() {

    private lateinit var database: DatabaseReference
    private lateinit var etFlightName: EditText
    private lateinit var etFlightNumber: EditText
    private lateinit var etDeparture: EditText
    private lateinit var etArrival: EditText
    private lateinit var btnAddFlight: Button

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_add_flight)

        // Initialize views
        etFlightName = findViewById(R.id.etFlightName)
        etFlightNumber = findViewById(R.id.etFlightNumber)
        etDeparture = findViewById(R.id.etDeparture)
        etArrival = findViewById(R.id.etArrival)
        btnAddFlight = findViewById(R.id.btnAddFlight)

        // Initialize Firebase Database reference
        database = FirebaseDatabase.getInstance().reference.child("flights")

        ViewCompat.setOnApplyWindowInsetsListener(btnAddFlight) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        btnAddFlight.setOnClickListener {
            addFlightToFirebase()
        }
    }

    private fun addFlightToFirebase() {
        val flightName = etFlightName.text.toString().trim()
        val flightNumber = etFlightNumber.text.toString().trim()
        val departure = etDeparture.text.toString().trim()
        val arrival = etArrival.text.toString().trim()

        if (flightName.isEmpty() || flightNumber.isEmpty() || departure.isEmpty() || arrival.isEmpty()) {
            Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show()
            return
        }

        val flightId = database.push().key!!
        val flight = Flight(flightId, flightName, flightNumber, departure, arrival)

        database.child(flightId).setValue(flight).addOnCompleteListener { task ->
            if (task.isSuccessful) {
                Toast.makeText(this, "Flight added successfully!", Toast.LENGTH_SHORT).show()
                clearFields()
            } else {
                Toast.makeText(this, "Failed to add flight", Toast.LENGTH_SHORT).show()
            }
        }
    }

    class Flight(flightId: String, flightName: String, flightNumber: String, departure: String, arrival: String) {

    }

    private fun clearFields() {
        etFlightName.text.clear()
        etFlightNumber.text.clear()
        etDeparture.text.clear()
        etArrival.text.clear()
    }
}
