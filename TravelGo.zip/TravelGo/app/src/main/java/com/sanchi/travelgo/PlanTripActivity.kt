package com.sanchi.travelgo

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.firestore.FirebaseFirestore

class PlanTripActivity : AppCompatActivity() {

    private lateinit var etDestination: EditText
    private lateinit var btnSaveTrip: Button
    private lateinit var firestore: FirebaseFirestore

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_plan_trip) // Ensure this layout exists

        // Initialize Firestore
        firestore = FirebaseFirestore.getInstance()

        // Bind the views
        etDestination = findViewById(R.id.etDestination)
        btnSaveTrip = findViewById(R.id.btnSaveTrip)

        // Handle the "Save Trip" button click
        btnSaveTrip.setOnClickListener {
            val destination = etDestination.text.toString().trim()

            if (destination.isEmpty()) {
                // Show a toast if the destination is empty
                Toast.makeText(this, "Please enter a destination", Toast.LENGTH_SHORT).show()
            } else {
                // Create a new trip object
                val trip = Trip(destination)

                // Save the trip to Firestore
                saveTripToFirestore(trip)
            }
        }
    }

    private fun saveTripToFirestore(trip: Trip) {
        // Add the trip data to the Firestore "trips" collection
        firestore.collection("trips")
            .add(trip)
            .addOnSuccessListener { documentReference ->
                Toast.makeText(this, "Trip saved successfully!", Toast.LENGTH_SHORT).show()
            }
            .addOnFailureListener { e ->
                Toast.makeText(this, "Error saving trip: ${e.message}", Toast.LENGTH_SHORT).show()
            }
    }
}

// Data class for Trip
data class Trip(
    val destination: String
)
